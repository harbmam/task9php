<?php 
    require_once 'class_nilaisantri.php';

    $ns1 = new NilaiSantri();
    $ns1->nama = 'fulan';
    $ns1->nilai = 80;
    echo $ns1->nama.' kuliah di '.$ns1->sekolah;
    echo '<br> Hasil Ujian : '.$ns1->nilai.' Dinyatakan '.$ns1->getHasil();
?>